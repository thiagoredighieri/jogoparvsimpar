package Interfaces;

public class ThreadControle implements Runnable{

	public void run() {
		// TODO Auto-generated method stub
		
	}

}
